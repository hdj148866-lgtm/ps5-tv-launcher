module.exports = {
  presets: ['module:@react-native/babel-preset'],
  plugins: [
    // Reanimated MUST be listed last.
    'react-native-reanimated/plugin',
  ],
};
