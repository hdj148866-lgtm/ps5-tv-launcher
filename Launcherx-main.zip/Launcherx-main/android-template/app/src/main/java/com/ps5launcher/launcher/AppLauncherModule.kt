package com.ps5launcher.launcher

import android.app.usage.StorageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Process
import android.provider.Settings
import android.util.Base64
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.bridge.WritableArray
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * Native bridge for the PS5-style TV launcher.
 *
 * Exposes:
 *   getInstalledApps()  -> all launchable TV + phone apps with base64 icons
 *   launchApp(pkg)      -> fires the leanback (or standard) launch intent
 *   getAppDetails(pkg)  -> version, install footprint, timestamps
 *   requestUninstall()  -> system uninstall dialog
 *   openAppSettings()   -> system "App info" screen
 *   openSystemSettings()-> Android TV settings
 */
class AppLauncherModule(private val reactContext: ReactApplicationContext) :
    ReactContextBaseJavaModule(reactContext) {

    override fun getName(): String = "AppLauncher"

    // ---------------------------------------------------------------
    // Installed apps
    // ---------------------------------------------------------------
    @ReactMethod
    fun getInstalledApps(promise: Promise) {
        try {
            val pm = reactContext.packageManager
            val seen = HashSet<String>()
            val out: WritableArray = Arguments.createArray()

            // TV apps first, then classic launcher apps (deduped).
            val intents = listOf(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER),
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),
            )

            for ((pass, intent) in intents.withIndex()) {
                for (ri in query(pm, intent)) {
                    val pkg = ri.activityInfo.packageName ?: continue
                    if (pkg == reactContext.packageName) continue
                    if (!seen.add(pkg)) continue

                    val ai = ri.activityInfo.applicationInfo ?: continue
                    val map = Arguments.createMap()
                    map.putString("label", ri.loadLabel(pm)?.toString() ?: pkg)
                    map.putString("packageName", pkg)
                    map.putString("icon", drawableToBase64(ri.loadIcon(pm)))
                    map.putBoolean("isGame", isGame(ai))
                    map.putBoolean("isTV", pass == 0)
                    map.putString("category", categoryLabel(ai))
                    out.pushMap(map)
                }
            }
            promise.resolve(out)
        } catch (t: Throwable) {
            promise.reject("E_APPS", "Failed to enumerate apps", t)
        }
    }

    private fun query(pm: PackageManager, intent: Intent) =
        if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, 0)
        }

    private fun isGame(ai: ApplicationInfo): Boolean {
        val flagGame = (ai.flags and ApplicationInfo.FLAG_GAME) != 0
        val catGame = Build.VERSION.SDK_INT >= 26 &&
            ai.category == ApplicationInfo.CATEGORY_GAME
        return flagGame || catGame
    }

    private fun categoryLabel(ai: ApplicationInfo): String {
        if (Build.VERSION.SDK_INT < 26) return if (isGame(ai)) "Game" else "App"
        return when (ai.category) {
            ApplicationInfo.CATEGORY_GAME -> "Game"
            ApplicationInfo.CATEGORY_AUDIO -> "Music & Audio"
            ApplicationInfo.CATEGORY_VIDEO -> "Video"
            ApplicationInfo.CATEGORY_IMAGE -> "Photos"
            ApplicationInfo.CATEGORY_SOCIAL -> "Social"
            ApplicationInfo.CATEGORY_NEWS -> "News"
            ApplicationInfo.CATEGORY_MAPS -> "Maps"
            ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Productivity"
            else -> if (isGame(ai)) "Game" else "App"
        }
    }

    private fun drawableToBase64(drawable: Drawable?, size: Int = 108): String? {
        if (drawable == null) return null
        return try {
            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            drawable.setBounds(0, 0, size, size)
            drawable.draw(canvas)
            val baos = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.PNG, 90, baos)
            bmp.recycle()
            "data:image/png;base64,".let { Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP) }
        } catch (t: Throwable) {
            null
        }
    }

    // ---------------------------------------------------------------
    // Launching
    // ---------------------------------------------------------------
    @ReactMethod
    fun launchApp(packageName: String, promise: Promise) {
        try {
            val pm = reactContext.packageManager
            val intent = pm.getLeanbackLaunchIntentForPackage(packageName)
                ?: pm.getLaunchIntentForPackage(packageName)
            if (intent == null) {
                promise.reject("E_LAUNCH", "No launch intent for $packageName")
                return
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            reactContext.startActivity(intent)
            promise.resolve(true)
        } catch (t: Throwable) {
            promise.reject("E_LAUNCH", "Launch failed for $packageName", t)
        }
    }

    // ---------------------------------------------------------------
    // Details
    // ---------------------------------------------------------------
    @ReactMethod
    fun getAppDetails(packageName: String, promise: Promise) {
        try {
            val pm = reactContext.packageManager
            val pi = pm.getPackageInfo(packageName, 0)
            val ai = pi.applicationInfo

            val map = Arguments.createMap()
            map.putString("versionName", pi.versionName ?: "—")
            map.putDouble("firstInstallTime", pi.firstInstallTime.toDouble())
            map.putDouble("lastUpdateTime", pi.lastUpdateTime.toDouble())
            map.putBoolean("isGame", ai?.let { isGame(it) } ?: false)
            map.putDouble("storageBytes", storageBytes(packageName, ai))
            promise.resolve(map)
        } catch (t: Throwable) {
            promise.reject("E_DETAILS", "No details for $packageName", t)
        }
    }

    private fun storageBytes(packageName: String, ai: ApplicationInfo?): Double {
        // True usage (app + data + cache) needs Usage Access; fall back to
        // on-disk APK size which needs no permission at all.
        if (Build.VERSION.SDK_INT >= 26 && ai != null) {
            try {
                val ssm = reactContext.getSystemService(Context.STORAGE_STATS_SERVICE)
                    as StorageStatsManager
                val stats = ssm.queryStatsForPackage(packageName, Process.myUserHandle())
                return (stats.appBytes + stats.dataBytes + stats.cacheBytes).toDouble()
            } catch (ignored: Throwable) {
            }
        }
        return try {
            File(ai?.sourceDir ?: "").length().toDouble()
        } catch (t: Throwable) {
            -1.0
        }
    }

    // ---------------------------------------------------------------
    // System shortcuts
    // ---------------------------------------------------------------
    @ReactMethod
    fun requestUninstall(packageName: String, promise: Promise) {
        try {
            val intent = Intent(Intent.ACTION_DELETE, Uri.parse("package:$packageName"))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            reactContext.startActivity(intent)
            promise.resolve(true)
        } catch (t: Throwable) {
            promise.reject("E_UNINSTALL", "Uninstall failed for $packageName", t)
        }
    }

    @ReactMethod
    fun openAppSettings(packageName: String, promise: Promise) {
        try {
            val intent = Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:$packageName"),
            )
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            reactContext.startActivity(intent)
            promise.resolve(true)
        } catch (t: Throwable) {
            promise.reject("E_SETTINGS", "App settings failed for $packageName", t)
        }
    }

    @ReactMethod
    fun openSystemSettings(promise: Promise) {
        try {
            val intent = Intent(Settings.ACTION_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            reactContext.startActivity(intent)
            promise.resolve(true)
        } catch (t: Throwable) {
            promise.reject("E_SETTINGS", "System settings failed", t)
        }
    }
}
