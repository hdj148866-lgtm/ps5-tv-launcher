import React, {useCallback, useEffect, useRef, useState} from 'react';
import {Pressable, StyleSheet, Text, View} from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';
import {C, METRICS, SPRINGS} from '../theme';
import {TABS, useLauncher} from '../state/LauncherContext';
import {CompassIcon, FilmIcon, GamepadIcon, SearchIcon} from './icons';

const ICONS = {
  games: GamepadIcon,
  media: FilmIcon,
  explore: CompassIcon,
  search: SearchIcon,
};

/**
 * PS5-style top navigation switcher.
 * - Focusing a tab switches the content instantly (no OK press needed),
 *   exactly like the PS5 "Games / Media" switcher.
 * - A shared-value underline springs between measured tab layouts.
 */
export default function NavBelt() {
  const {state, dispatch, sfx} = useLauncher();
  const [focusedTab, setFocusedTab] = useState(state.tab);
  const layouts = useRef({});
  const underlineX = useSharedValue(0);
  const underlineW = useSharedValue(0);

  const moveUnderline = useCallback(
    (id) => {
      const m = layouts.current[id];
      if (!m) {
        return;
      }
      underlineX.value = withSpring(m.x + 14, SPRINGS.snap);
      underlineW.value = withSpring(Math.max(m.w - 28, 12), SPRINGS.snap);
    },
    [underlineX, underlineW],
  );

  useEffect(() => {
    moveUnderline(focusedTab);
  }, [focusedTab, moveUnderline]);

  const underlineStyle = useAnimatedStyle(() => ({
    transform: [{translateX: underlineX.value}],
    width: underlineW.value,
  }));

  const selectTab = useCallback(
    (id) => {
      if (state.tab !== id) {
        dispatch({type: 'SET_TAB', id});
      }
    },
    [dispatch, state.tab],
  );

  return (
    <View style={styles.wrap}>
      {TABS.map((tab) => {
        const isActive = state.tab === tab.id;
        const isFocused = focusedTab === tab.id;
        const Icon = ICONS[tab.id];
        return (
          <Pressable
            key={tab.id}
            focusable
            onLayout={(e) => {
              layouts.current[tab.id] = {
                x: e.nativeEvent.layout.x,
                w: e.nativeEvent.layout.width,
              };
              moveUnderline(focusedTab);
            }}
            onFocus={() => {
              setFocusedTab(tab.id);
              sfx.tick();
              dispatch({type: 'SET_ZONE', zone: 'nav'});
              selectTab(tab.id); // instant content switch on focus, PS5-style
            }}
            onPress={() => selectTab(tab.id)}
            style={styles.item}>
            <Icon size={19} color={isFocused ? '#ffffff' : C.sub} />
            <Text
              style={[
                styles.label,
                {color: isFocused ? '#ffffff' : isActive ? '#dfe3ee' : C.sub},
              ]}>
              {tab.label}
            </Text>
          </Pressable>
        );
      })}
      <Animated.View style={[styles.underline, underlineStyle]} />
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    height: METRICS.NAV_H,
    marginHorizontal: 44,
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
  },
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 10,
    marginRight: 6,
  },
  label: {
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: 2.4,
    marginLeft: 8,
  },
  underline: {
    position: 'absolute',
    left: 0,
    bottom: 2,
    height: 3,
    borderRadius: 2,
    backgroundColor: '#ffffff',
  },
});
