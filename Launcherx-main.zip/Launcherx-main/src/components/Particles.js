import React, {useEffect, useMemo} from 'react';
import {StyleSheet, useWindowDimensions, View} from 'react-native';
import Animated, {
  Easing,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withRepeat,
  withTiming,
} from 'react-native-reanimated';

const COUNT = 14;

/**
 * Ambient "dust motes" drifting behind the UI — that subtle PS5 alive-ness.
 * Every particle is a dedicated UI-thread animation loop (opacity pulse +
 * slow vertical drift), desynchronized with random delays.
 * 14 tiny views ≈ zero cost even on a Firestick.
 */
function Mote({cfg}) {
  const p = useSharedValue(0);
  useEffect(() => {
    p.value = withDelay(
      cfg.delay,
      withRepeat(withTiming(1, {duration: cfg.duration, easing: Easing.inOut(Easing.quad)}), -1, true),
    );
  }, [p, cfg]);

  const style = useAnimatedStyle(() => ({
    opacity: 0.12 + p.value * cfg.peak,
    transform: [
      {translateX: cfg.x},
      {translateY: cfg.y - p.value * cfg.drift},
      {scale: 0.8 + p.value * 0.5},
    ],
  }));

  return (
    <Animated.View
      style={[
        styles.mote,
        {
          width: cfg.size,
          height: cfg.size,
          borderRadius: cfg.size / 2,
          backgroundColor: cfg.tint,
        },
        style,
      ]}
    />
  );
}

// Deterministic pseudo-random so re-renders don't reshuffle the field.
function rand(seed) {
  let s = seed % 2147483647;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

export default function Particles() {
  const {width, height} = useWindowDimensions();
  const configs = useMemo(() => {
    const r = rand(1337);
    return new Array(COUNT).fill(0).map((_, i) => ({
      key: i,
      x: r() * width,
      y: height * 0.15 + r() * height * 0.75,
      size: 2 + r() * 3.5,
      drift: 26 + r() * 60,
      duration: 5200 + r() * 6400,
      delay: r() * 4000,
      peak: 0.25 + r() * 0.3,
      tint: r() > 0.72 ? '#5aa9ff' : '#ffffff',
    }));
  }, [width, height]);

  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="none">
      {configs.map((c) => (
        <Mote key={c.key} cfg={c} />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  mote: {position: 'absolute', top: 0, left: 0},
});
