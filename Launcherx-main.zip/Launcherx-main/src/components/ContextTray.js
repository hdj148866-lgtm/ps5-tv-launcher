import React, {useEffect, useState} from 'react';
import {Pressable, StyleSheet, Text, View} from 'react-native';
import Animated, {
  FadeInDown,
  interpolateColor,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';
import LinearGradient from 'react-native-linear-gradient';
import {C, METRICS, SPRINGS} from '../theme';
import {selectFocusedApp, useLauncher} from '../state/LauncherContext';
import AppLauncherNative from '../modules/AppLauncherNative';
import useAppDetails from '../hooks/useAppDetails';
import {formatBytes, formatDate} from '../utils/format';
import {artFor} from '../utils/art';
import {GearIcon, InfoIcon, PlayIcon, TrashIcon} from './icons';

/**
 * Contextual action cards (PS5 "activity cards" layer).
 * Revealed with D-PAD DOWN from the shelf. The shelf lifts/dims, the tray
 * slides up with a stagger, and "Resume" takes preferred focus.
 * D-PAD UP / BACK collapses it and returns focus to the exact card you
 * came from (focus memory).
 */

function TrayCard({icon: Icon, title, sub, accent, danger, preferred, onPress, onFocusZone, delay}) {
  const {sfx} = useLauncher();
  const [focused, setFocused] = useState(false);
  const f = useSharedValue(0);
  useEffect(() => {
    f.value = withSpring(focused ? 1 : 0, SPRINGS.focus);
  }, [focused, f]);

  const style = useAnimatedStyle(() => ({
    transform: [{scale: 1 + f.value * 0.05}],
    backgroundColor: interpolateColor(
      f.value,
      [0, 1],
      accent
        ? ['rgba(0,112,209,0.55)', '#0a84e8']
        : ['rgba(255,255,255,0.055)', 'rgba(255,255,255,0.16)'],
    ),
    borderColor: interpolateColor(
      f.value,
      [0, 1],
      ['rgba(255,255,255,0.09)', 'rgba(255,255,255,0.85)'],
    ),
  }));

  const titleColor = danger ? C.danger : '#ffffff';

  return (
    <Animated.View entering={FadeInDown.delay(delay).springify()} style={styles.cell}>
      <Pressable
        focusable
        hasTVPreferredFocus={preferred}
        onFocus={() => {
          setFocused(true);
          onFocusZone && onFocusZone();
          sfx.tick();
        }}
        onBlur={() => setFocused(false)}
        onPress={() => {
          sfx.select();
          onPress && onPress();
        }}
        style={styles.pressable}>
        <Animated.View style={[styles.card, style]}>
          {accent && focused ? (
            <LinearGradient
              colors={[C.accent, C.accentDeep]}
              start={{x: 0, y: 0}}
              end={{x: 1, y: 1}}
              style={StyleSheet.absoluteFill}
            />
          ) : null}
          <View style={styles.iconWrap}>
            <Icon size={24} color={danger ? C.danger : '#ffffff'} />
          </View>
          <View style={styles.textWrap}>
            <Text style={[styles.cardTitle, {color: titleColor}]} numberOfLines={1}>
              {title}
            </Text>
            <Text style={styles.cardSub} numberOfLines={2}>
              {sub}
            </Text>
          </View>
        </Animated.View>
      </Pressable>
    </Animated.View>
  );
}

export default function ContextTray() {
  const {state, dispatch} = useLauncher();
  const app = selectFocusedApp(state);
  const details = useAppDetails(app, 0);

  if (!state.trayOpen || !app) {
    return null;
  }

  const art = artFor(app);

  const sizeLine = details
    ? `${formatBytes(details.storageBytes)}  •  v${details.versionName || '—'}`
    : 'Reading package info…';
  const updatedLine = details
    ? `Updated ${formatDate(details.lastUpdateTime)}`
    : ' ';

  return (
    <View style={styles.wrap} pointerEvents="box-none">
      <Animated.View entering={FadeInDown.springify()} style={styles.inner}>
        <View style={styles.headRow}>
          <View style={[styles.headBar, {backgroundColor: art.accent}]} />
          <Text style={styles.headText}>{`${app.label.toUpperCase()}  —  QUICK ACTIONS`}</Text>
        </View>

        <View style={styles.row}>
          <TrayCard
            icon={PlayIcon}
            title={app.isGame ? 'Play' : 'Open'}
            sub="Resume where you left off"
            accent
            preferred
            delay={30}
            onFocusZone={() => dispatch({type: 'SET_ZONE', zone: 'tray'})}
            onPress={() => AppLauncherNative.launchApp(app.packageName, app.label)}
          />
          <TrayCard
            icon={InfoIcon}
            title="Details"
            sub={`${sizeLine}\n${updatedLine}`}
            delay={95}
            onFocusZone={() => dispatch({type: 'SET_ZONE', zone: 'tray'})}
            onPress={() => AppLauncherNative.openAppSettings(app.packageName)}
          />
          <TrayCard
            icon={GearIcon}
            title="App Settings"
            sub="Permissions, notifications, defaults"
            delay={160}
            onFocusZone={() => dispatch({type: 'SET_ZONE', zone: 'tray'})}
            onPress={() => AppLauncherNative.openAppSettings(app.packageName)}
          />
          <TrayCard
            icon={TrashIcon}
            title="Uninstall"
            sub="Remove from this device"
            danger
            delay={225}
            onFocusZone={() => dispatch({type: 'SET_ZONE', zone: 'tray'})}
            onPress={() => {
              AppLauncherNative.clearDetailsCache(app.packageName);
              AppLauncherNative.requestUninstall(app.packageName, app.label);
            }}
          />
        </View>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 20,
  },
  inner: {
    marginHorizontal: 48,
    borderRadius: 20,
    backgroundColor: 'rgba(10,12,16,0.72)',
    borderWidth: 1,
    borderColor: C.stroke,
    paddingHorizontal: 22,
    paddingTop: 14,
    paddingBottom: 18,
  },
  headRow: {flexDirection: 'row', alignItems: 'center', marginBottom: 12},
  headBar: {width: 16, height: 3, borderRadius: 2, marginRight: 10},
  headText: {color: C.sub, fontSize: 12, fontWeight: '800', letterSpacing: 2.6},
  row: {flexDirection: 'row'},
  cell: {flex: 1, marginRight: 14},
  pressable: {flex: 1},
  card: {
    height: METRICS.TRAY_CARD_H,
    borderRadius: METRICS.TRAY_CARD_R,
    borderWidth: 1.5,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 18,
    overflow: 'hidden',
  },
  iconWrap: {marginRight: 14},
  textWrap: {flex: 1},
  cardTitle: {fontSize: 16.5, fontWeight: '700', letterSpacing: 0.3},
  cardSub: {color: 'rgba(224,227,238,0.72)', fontSize: 11.5, marginTop: 3, lineHeight: 15},
});
