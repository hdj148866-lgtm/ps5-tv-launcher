import React from 'react';
import {Platform, StyleSheet, Text, View} from 'react-native';
import Animated, {useAnimatedStyle} from 'react-native-reanimated';
import {C, DUR, FONT, METRICS} from '../theme';
import {selectFocusedApp, useLauncher} from '../state/LauncherContext';
import useCrossFade from '../hooks/useCrossFade';
import useAppDetails from '../hooks/useAppDetails';
import {formatBytes} from '../utils/format';

/**
 * The "staged" app hero block above the shelf:
 * eyebrow (category) / huge title / metadata row.
 * Uses the same double-buffer cross-fade as the background, so the whole
 * top half of the screen swaps as one coherent, 300ms motion.
 */
export default function AppTitleStage() {
  const {state} = useLauncher();
  const app = selectFocusedApp(state);
  const key = app ? app.packageName : '@@none';
  const details = useAppDetails(app);

  const {cur, prev, t} = useCrossFade(app, key, DUR.crossfade);

  const frontStyle = useAnimatedStyle(() => ({
    opacity: t.value,
    transform: [{translateY: (1 - t.value) * 12}],
  }));

  const renderBlock = (item, animated) => {
    if (!item) {
      return null;
    }
    const eyebrow = `${item.isGame ? 'GAME' : 'APPLICATION'}${
      item.category ? `  •  ${String(item.category).toUpperCase()}` : ''
    }`;
    return (
      <Animated.View
        key={item.packageName}
        style={[styles.block, animated && frontStyle]}
        pointerEvents="none">
        <View style={styles.eyebrowRow}>
          <View style={styles.eyebrowBar} />
          <Text style={styles.eyebrow}>{eyebrow}</Text>
        </View>
        <Text style={styles.title} numberOfLines={1}>
          {item.label}
        </Text>
        <View style={styles.metaRow}>
          <Text style={styles.meta} numberOfLines={1}>
            {item.packageName}
          </Text>
          {details ? (
            <Text style={styles.metaDim} numberOfLines={1}>
              {`  •  ${formatBytes(details.storageBytes)}  •  v${details.versionName || '—'}`}
            </Text>
          ) : null}
        </View>
      </Animated.View>
    );
  };

  // Reserve a fixed height at all times so the shelf NEVER reflows.
  return (
    <View style={styles.wrap}>
      {prev ? renderBlock(prev, false) : null}
      {renderBlock(cur, true)}
    </View>
  );
}

const MONO = Platform.select({android: 'monospace', default: 'Menlo'});

const styles = StyleSheet.create({
  wrap: {
    height: METRICS.TITLE_H,
    paddingHorizontal: 56,
    justifyContent: 'flex-start',
  },
  block: {
    ...StyleSheet.absoluteFillObject,
    left: 56,
    right: 56,
  },
  eyebrowRow: {flexDirection: 'row', alignItems: 'center'},
  eyebrowBar: {
    width: 18,
    height: 3,
    borderRadius: 2,
    backgroundColor: C.accent,
    marginRight: 10,
  },
  eyebrow: {
    color: C.sub,
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 3,
  },
  title: {
    color: C.text,
    fontSize: 44,
    fontWeight: '800',
    letterSpacing: 0.4,
    marginTop: 6,
    includeFontPadding: false,
  },
  metaRow: {flexDirection: 'row', alignItems: 'center', marginTop: 6},
  meta: {
    color: C.sub,
    fontSize: 13,
    fontFamily: MONO || FONT.mono,
    letterSpacing: 0.3,
    flexShrink: 1,
  },
  metaDim: {color: 'rgba(160,165,181,0.75)', fontSize: 13},
});
