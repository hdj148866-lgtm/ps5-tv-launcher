import React, {useCallback, useEffect, useMemo, useRef} from 'react';
import {ScrollView, StyleSheet, Text, useWindowDimensions, View} from 'react-native';
import Animated, {
  Easing,
  interpolate,
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from 'react-native-reanimated';
import {C, DUR, METRICS} from '../theme';
import {appsForTab, useLauncher} from '../state/LauncherContext';
import AppLauncherNative from '../modules/AppLauncherNative';
import AppCard from './AppCard';
import FocusGuide from './FocusGuide';
import {ChevronDownIcon} from './icons';

/**
 * The horizontal PS5 "shelf".
 *
 * - One ScrollView (not FlatList): launchers have < ~150 tiles and recycling
 *   a focused off-screen row on Android TV is a known focus-loss hazard.
 * - Centering uses the padding trick: content is padded by (screen-card)/2
 *   so card X == index * UNIT, and we smooth-scroll to keep focus centered.
 * - A TVFocusGuideView with `destinations` = last focused card implements
 *   true "focus memory" when focus re-enters from the nav belt.
 * - While the tray is open the whole shelf dims/lifts and becomes
 *   non-focusable, and focus routing lives in the central dispatcher.
 */
export default function AppShelf() {
  const {state, dispatch, sfx, cardRefs} = useLauncher();
  const apps = appsForTab(state);
  const {width} = useWindowDimensions();

  const UNIT = METRICS.CARD_W + METRICS.CARD_GAP;
  const pad = Math.max((width - METRICS.CARD_W) / 2, 0);
  const scrollRef = useRef(null);

  // Stable ref objects per app — these feed TVFocusGuideView destinations
  // and the imperative focusNode() fallback.
  const refObjs = useMemo(() => apps.map(() => React.createRef()), [apps]);
  useEffect(() => {
    refObjs.forEach((r, i) => cardRefs.set(i, r));
    return () => cardRefs.clear();
  }, [refObjs, cardRefs]);

  // Auto-center the focused tile.
  useEffect(() => {
    const x = Math.max(state.focusedIndex * UNIT, 0);
    const id = requestAnimationFrame(() => {
      if (scrollRef.current) {
        scrollRef.current.scrollTo({x, animated: true});
      }
    });
    return () => cancelAnimationFrame(id);
  }, [state.focusedIndex, apps, UNIT]);

  // Shelf "goes away" choreography while the tray is open.
  const sh = useSharedValue(0);
  useEffect(() => {
    sh.value = withTiming(state.trayOpen ? 1 : 0, {
      duration: DUR.shelfShift,
      easing: Easing.out(Easing.cubic),
    });
  }, [state.trayOpen, sh]);
  const shelfStyle = useAnimatedStyle(() => ({
    opacity: interpolate(sh.value, [0, 1], [1, 0.32]),
    transform: [
      {translateY: interpolate(sh.value, [0, 1], [0, -30])},
      {scale: interpolate(sh.value, [0, 1], [1, 0.965])},
    ],
  }));

  const handleCardFocus = useCallback(
    (index) => {
      dispatch({type: 'FOCUS_APP', index, zone: 'shelf'});
      sfx.tick();
    },
    [dispatch, sfx],
  );

  const handleCardPress = useCallback(
    (app) => {
      sfx.select();
      AppLauncherNative.launchApp(app.packageName, app.label);
    },
    [sfx],
  );

  if (!state.booted) {
    return <View style={styles.bootSpace} />;
  }

  const guideTargets =
    refObjs[state.focusedIndex] != null ? [refObjs[state.focusedIndex]] : undefined;

  return (
    <View style={styles.region}>
      <FocusGuide destinations={guideTargets} style={styles.guide}>
        <Animated.View style={shelfStyle}>
          <ScrollView
            ref={scrollRef}
            horizontal
            showsHorizontalScrollIndicator={false}
            scrollEnabled={false}
            overScrollMode="never"
            contentContainerStyle={{paddingHorizontal: pad, paddingVertical: 26}}>
            {apps.map((app, i) => (
              <AppCard
                key={app.packageName}
                ref={refObjs[i]}
                app={app}
                index={i}
                focusable={!state.trayOpen}
                hasTVPreferredFocus={
                  i === state.focusedIndex && !state.trayOpen && state.zone !== 'nav'
                }
                onFocus={handleCardFocus}
                onPress={handleCardPress}
              />
            ))}
          </ScrollView>
        </Animated.View>
      </FocusGuide>

      {state.zone === 'shelf' && !state.trayOpen ? (
        <View style={styles.hint} pointerEvents="none">
          <ChevronDownIcon size={15} color={C.sub} />
          <Text style={styles.hintText}>Quick actions</Text>
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  region: {flex: 1, justifyContent: 'flex-start'},
  guide: {flexGrow: 0},
  bootSpace: {height: METRICS.CARD_H + 90},
  hint: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    paddingHorizontal: 52,
    marginTop: 4,
    opacity: 0.85,
  },
  hintText: {color: C.sub, fontSize: 12.5, fontWeight: '600', marginLeft: 6, letterSpacing: 0.4},
});
