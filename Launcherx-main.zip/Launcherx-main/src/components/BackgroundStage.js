import React, {useEffect} from 'react';
import {StyleSheet, Text, View} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Animated, {
  Easing,
  interpolate,
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from 'react-native-reanimated';
import {DUR, VIGNETTE, VIGNETTE_LOCATIONS} from '../theme';
import {selectFocusedApp, useLauncher} from '../state/LauncherContext';
import {artFor, hexToRgba} from '../utils/art';
import useCrossFade from '../hooks/useCrossFade';

/**
 * Full-screen dynamic key-art.
 *
 * Perf strategy (60fps on a Chromecast):
 *  - double-buffer cross-fade: only two layers ever exist, both cheap
 *    LinearGradients (no image decode on the UI thread);
 *  - the outgoing layer parks at opacity 1 while the incoming one fades in;
 *  - a 15s Ken Burns drift rides on the same animated node;
 *  - vignette + top scrim are static gradients — zero per-frame cost.
 */

function ArtLayer({art}) {
  return (
    <View style={StyleSheet.absoluteFill}>
      <LinearGradient
        colors={art.grad}
        start={{x: 0.1, y: 0}}
        end={{x: 0.9, y: 1}}
        style={StyleSheet.absoluteFill}
      />
      {/* oversized watermark monogram, PS5 "key-art" substitute */}
      <Text style={styles.watermark} allowFontScaling={false}>
        {art.glyph}
      </Text>
      <View style={[styles.glowBlob, {backgroundColor: art.accentSoft}]} />
    </View>
  );
}

export default function BackgroundStage() {
  const {state} = useLauncher();
  const app = selectFocusedApp(state);
  const key = app ? app.packageName : '@@none';
  const art = artFor(app);

  const {cur, prev, t} = useCrossFade(art, key, DUR.crossfade);

  // Ken Burns: restart a slow drift whenever the art changes.
  const kb = useSharedValue(0);
  useEffect(() => {
    kb.value = 0;
    kb.value = withTiming(1, {duration: DUR.kenburns, easing: Easing.inOut(Easing.quad)});
  }, [key, kb]);

  const frontStyle = useAnimatedStyle(() => ({
    opacity: t.value,
    transform: [
      {scale: interpolate(kb.value, [0, 1], [1.04, 1.12])},
      {translateX: interpolate(kb.value, [0, 1], [0, -14])},
    ],
  }));

  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="none">
      {prev ? <ArtLayer art={prev} /> : <ArtLayer art={cur} staticBase />}
      <Animated.View style={[StyleSheet.absoluteFill, frontStyle]}>
        <ArtLayer art={cur} />
      </Animated.View>

      {/* brand glow bleeding in from the top */}
      <LinearGradient
        colors={[hexToRgba('#0070d1', 0.22), 'rgba(0,112,209,0)']}
        start={{x: 0.5, y: 0}}
        end={{x: 0.5, y: 1}}
        style={styles.topGlow}
      />
      {/* main vignette */}
      <LinearGradient
        colors={VIGNETTE}
        locations={VIGNETTE_LOCATIONS}
        start={{x: 0.5, y: 0}}
        end={{x: 0.5, y: 1}}
        style={StyleSheet.absoluteFill}
      />
      {/* extra scrim behind the header for clock legibility */}
      <LinearGradient
        colors={['rgba(10,12,16,0.55)', 'rgba(10,12,16,0)']}
        start={{x: 0.5, y: 0}}
        end={{x: 0.5, y: 1}}
        style={styles.headerScrim}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  watermark: {
    position: 'absolute',
    right: -24,
    bottom: -110,
    fontSize: 420,
    fontWeight: '800',
    color: 'rgba(255,255,255,0.05)',
    includeFontPadding: false,
  },
  glowBlob: {
    position: 'absolute',
    top: '18%',
    left: '12%',
    width: 340,
    height: 340,
    borderRadius: 170,
    opacity: 0.5,
  },
  topGlow: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: '55%',
  },
  headerScrim: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 170,
  },
});
