import React, {useEffect, useState} from 'react';
import {Pressable, StyleSheet, Text, ToastAndroid, View} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Animated, {
  cancelAnimation,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import {C, METRICS, SPRINGS} from '../theme';
import {useLauncher} from '../state/LauncherContext';
import {formatClock} from '../utils/format';
import useClock from '../hooks/useClock';
import AppLauncherNative from '../modules/AppLauncherNative';
import {BellIcon, GearIcon, UserIcon, WifiIcon} from './icons';

/** Pulsing notification dot (ambient, runs forever on the UI thread). */
function NotificationDot() {
  const p = useSharedValue(0);
  useEffect(() => {
    p.value = withRepeat(withTiming(1, {duration: 1400}), -1, true);
  }, [p]);
  const style = useAnimatedStyle(() => ({
    opacity: 0.55 + p.value * 0.45,
    transform: [{scale: 0.85 + p.value * 0.3}],
  }));
  return <Animated.View style={[styles.dot, style]} />;
}

function Avatar() {
  const {dispatch, sfx} = useLauncher();
  const [focused, setFocused] = useState(false);
  const f = useSharedValue(0);
  useEffect(() => {
    f.value = withSpring(focused ? 1 : 0, SPRINGS.focus);
  }, [focused, f]);
  const ring = useAnimatedStyle(() => ({
    transform: [{scale: 1 + f.value * 0.08}],
    borderColor: focused ? '#ffffff' : 'rgba(255,255,255,0.14)',
  }));
  return (
    <Pressable
      focusable
      onFocus={() => {
        setFocused(true);
        dispatch({type: 'SET_ZONE', zone: 'header'});
        sfx.tick();
      }}
      onBlur={() => setFocused(false)}
      onPress={() => {
        sfx.select();
        ToastAndroid.show('Aurora Player 1', ToastAndroid.SHORT);
      }}
      style={styles.focusHit}>
      <Animated.View style={[styles.avatarRing, ring]}>
        <LinearGradient
          colors={[C.accent, C.accentDeep]}
          start={{x: 0, y: 0}}
          end={{x: 1, y: 1}}
          style={styles.avatar}>
          <UserIcon size={24} color="#fff" />
        </LinearGradient>
      </Animated.View>
    </Pressable>
  );
}

function HeaderButton({onPress, children, label}) {
  const {dispatch, sfx} = useLauncher();
  const [focused, setFocused] = useState(false);
  const f = useSharedValue(0);
  useEffect(() => {
    f.value = withSpring(focused ? 1 : 0, SPRINGS.focus);
  }, [focused, f]);
  const style = useAnimatedStyle(() => ({
    transform: [{scale: 1 + f.value * 0.1}],
    backgroundColor: focused ? 'rgba(255,255,255,0.14)' : 'rgba(255,255,255,0.0)',
    borderColor: focused ? 'rgba(255,255,255,0.8)' : 'rgba(255,255,255,0.0)',
  }));
  return (
    <Pressable
      focusable
      accessibilityLabel={label}
      onFocus={() => {
        setFocused(true);
        dispatch({type: 'SET_ZONE', zone: 'header'});
        sfx.tick();
      }}
      onBlur={() => setFocused(false)}
      onPress={() => {
        sfx.select();
        onPress && onPress();
      }}
      style={styles.focusHit}>
      <Animated.View style={[styles.iconButton, style]}>{children}</Animated.View>
    </Pressable>
  );
}

export default function Header() {
  const now = useClock();
  const {hhmm, mer} = formatClock(now);

  return (
    <View style={styles.row} pointerEvents="box-none">
      <View style={styles.left}>
        <Avatar />
        <HeaderButton
          label="Notifications"
          onPress={() => ToastAndroid.show('No new notifications', ToastAndroid.SHORT)}>
          <View>
            <BellIcon size={23} color="#dfe3ee" />
            <NotificationDot />
          </View>
        </HeaderButton>
      </View>

      <View style={styles.right}>
        <View style={styles.clockWrap}>
          <Text style={styles.clock}>{hhmm}</Text>
          <Text style={styles.mer}>{` ${mer}`}</Text>
        </View>
        <View style={styles.wifi}>
          <WifiIcon size={21} color={C.sub} />
        </View>
        <HeaderButton
          label="Settings"
          onPress={() => AppLauncherNative.openSystemSettings()}>
          <GearIcon size={23} color="#dfe3ee" />
        </HeaderButton>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    height: METRICS.HEADER_H,
    paddingHorizontal: 44,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  left: {flexDirection: 'row', alignItems: 'center'},
  right: {flexDirection: 'row', alignItems: 'center'},
  focusHit: {padding: 4},
  avatarRing: {
    width: 52,
    height: 52,
    borderRadius: 26,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 14,
  },
  avatar: {
    width: 42,
    height: 42,
    borderRadius: 21,
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  dot: {
    position: 'absolute',
    top: -2,
    right: -2,
    width: 9,
    height: 9,
    borderRadius: 5,
    backgroundColor: C.danger,
  },
  clockWrap: {flexDirection: 'row', alignItems: 'flex-end', marginRight: 18},
  clock: {
    color: C.text,
    fontSize: 27,
    fontWeight: '700',
    fontVariant: ['tabular-nums'],
    letterSpacing: 0.5,
  },
  mer: {color: C.sub, fontSize: 13, fontWeight: '600', marginBottom: 3},
  wifi: {marginRight: 10, opacity: 0.9},
});
