import React, {useMemo} from 'react';
import {ScrollView, StyleSheet, Text, TextInput, View} from 'react-native';
import {C} from '../theme';
import {useLauncher} from '../state/LauncherContext';
import AppLauncherNative from '../modules/AppLauncherNative';
import AppCard from './AppCard';
import {SearchIcon} from './icons';

/**
 * PS5-style search: a focusable pill input (D-PAD select summons the system
 * IME) with a live-filtered results shelf underneath. D-PAD DOWN from the
 * input lands on the first result via native spatial focus.
 */
export default function SearchPanel() {
  const {state, dispatch, sfx} = useLauncher();
  const q = state.query.trim().toLowerCase();

  const results = useMemo(() => {
    if (!q) {
      return state.apps;
    }
    return state.apps.filter(
      (a) =>
        a.label.toLowerCase().includes(q) ||
        a.packageName.toLowerCase().includes(q),
    );
  }, [q, state.apps]);

  return (
    <View style={styles.wrap}>
      <Text style={styles.title}>Search</Text>

      <View style={styles.inputRow}>
        <SearchIcon size={20} color={C.sub} />
        <TextInput
          style={styles.input}
          value={state.query}
          onChangeText={(text) => dispatch({type: 'SET_QUERY', query: text})}
          placeholder="Search your apps and games…"
          placeholderTextColor="rgba(160,165,181,0.6)"
          returnKeyType="search"
          autoCapitalize="none"
          autoCorrect={false}
          onFocus={() => dispatch({type: 'SET_ZONE', zone: 'search'})}
        />
      </View>

      <Text style={styles.count}>
        {q ? `${results.length} result${results.length === 1 ? '' : 's'}` : 'Browse everything'}
      </Text>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        overScrollMode="never"
        contentContainerStyle={styles.results}>
        {results.map((app, i) => (
          <AppCard
            key={app.packageName}
            app={app}
            index={i}
            size="small"
            onFocus={() => {
              dispatch({type: 'SET_ZONE', zone: 'search'});
              sfx.tick();
            }}
            onPress={() => {
              sfx.select();
              AppLauncherNative.launchApp(app.packageName, app.label);
            }}
          />
        ))}
        {results.length === 0 ? (
          <Text style={styles.empty}>{`Nothing matches "${state.query}"`}</Text>
        ) : null}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {flex: 1, paddingHorizontal: 56, paddingTop: 26},
  title: {color: C.text, fontSize: 34, fontWeight: '800', letterSpacing: 0.4},
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 24,
    backgroundColor: C.faint,
    borderWidth: 1.5,
    borderColor: C.stroke,
    borderRadius: 999,
    paddingHorizontal: 22,
    height: 56,
  },
  input: {
    flex: 1,
    marginLeft: 12,
    color: C.text,
    fontSize: 17,
    padding: 0,
  },
  count: {color: C.sub, fontSize: 13, fontWeight: '600', marginTop: 22, letterSpacing: 0.5},
  results: {paddingVertical: 26, paddingRight: 56},
  empty: {color: C.sub, fontSize: 15, marginTop: 30},
});
