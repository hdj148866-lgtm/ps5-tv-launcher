import React from 'react';
import {View, TVFocusGuideView} from 'react-native';

/**
 * Wrapper around TVFocusGuideView (react-native-tvos) that degrades to a
 * plain View if the app is ever run on a non-TV build of React Native.
 *
 * `destinations`  : array of refs — where focus should land when it ENTERs
 *                   this region from the outside (this is our "focus memory").
 * `autoFocus`     : ask the guide to focus its first focusable child on mount.
 */
export default function FocusGuide({destinations, autoFocus, style, children}) {
  if (TVFocusGuideView) {
    return (
      <TVFocusGuideView destinations={destinations} autoFocus={autoFocus} style={style}>
        {children}
      </TVFocusGuideView>
    );
  }
  return <View style={style}>{children}</View>;
}
