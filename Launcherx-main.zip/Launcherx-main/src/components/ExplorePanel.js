import React, {useEffect, useState} from 'react';
import {Pressable, StyleSheet, Text, View} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Animated, {
  interpolate,
  interpolateColor,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';
import {C, SPRINGS} from '../theme';
import {appsForTab, useLauncher} from '../state/LauncherContext';
import AppLauncherNative from '../modules/AppLauncherNative';
import {artFor} from '../utils/art';

/** One large "featured" tile for the Explore tab. */
function HeroCard({app, tag}) {
  const {dispatch, sfx} = useLauncher();
  const [focused, setFocused] = useState(false);
  const f = useSharedValue(0);
  useEffect(() => {
    f.value = withSpring(focused ? 1 : 0, SPRINGS.focus);
  }, [focused, f]);

  const style = useAnimatedStyle(() => ({
    transform: [{scale: interpolate(f.value, [0, 1], [0.97, 1.05])}],
    borderColor: interpolateColor(
      f.value,
      [0, 1],
      ['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.9)'],
    ),
    zIndex: f.value > 0.4 ? 20 : 1,
  }));
  const halo = useAnimatedStyle(() => ({
    opacity: interpolate(f.value, [0, 1], [0, 0.7]),
  }));

  const art = artFor(app);
  return (
    <View style={styles.cell}>
      <Animated.View style={[styles.cellHalo, {backgroundColor: art.accentSoft}, halo]} />
      <Animated.View style={[styles.heroFrame, style]}>
        <Pressable
          focusable
          accessibilityLabel={`Open ${app.label}`}
          onFocus={() => {
            setFocused(true);
            dispatch({type: 'SET_ZONE', zone: 'explore'});
            sfx.tick();
          }}
          onBlur={() => setFocused(false)}
          onPress={() => {
            sfx.select();
            AppLauncherNative.launchApp(app.packageName, app.label);
          }}
          style={styles.pressable}>
          <LinearGradient
            colors={art.grad}
            start={{x: 0, y: 0}}
            end={{x: 1, y: 1}}
            style={StyleSheet.absoluteFill}
          />
          <Text style={styles.heroGlyph}>{art.glyph}</Text>
          <LinearGradient
            colors={['rgba(10,12,16,0)', 'rgba(10,12,16,0.72)']}
            start={{x: 0.5, y: 0.35}}
            end={{x: 0.5, y: 1}}
            style={StyleSheet.absoluteFill}
          />
          <View style={styles.heroBottom}>
            <View style={styles.tag}>
              <Text style={styles.tagText}>{tag}</Text>
            </View>
            <Text style={styles.heroTitle} numberOfLines={1}>
              {app.label}
            </Text>
            <Text style={styles.heroSub} numberOfLines={1}>
              {app.isGame ? 'Jump back in' : 'Continue watching'}
            </Text>
          </View>
        </Pressable>
      </Animated.View>
    </View>
  );
}

const TAGS = ['FEATURED', 'TRENDING', 'NEW FOR YOU', 'CONTINUE'];

export default function ExplorePanel() {
  const {state} = useLauncher();
  const heroes = appsForTab(state).slice(0, 4);

  return (
    <View style={styles.wrap}>
      <Text style={styles.title}>Explore</Text>
      <Text style={styles.subtitle}>Featured picks from your library</Text>
      <View style={styles.row}>
        {heroes.map((app, i) => (
          <HeroCard key={app.packageName} app={app} tag={TAGS[i % TAGS.length]} />
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {flex: 1, paddingHorizontal: 56, paddingTop: 26},
  title: {color: C.text, fontSize: 34, fontWeight: '800', letterSpacing: 0.4},
  subtitle: {color: C.sub, fontSize: 14, marginTop: 6, letterSpacing: 0.3},
  row: {flexDirection: 'row', marginTop: 30},
  cell: {flex: 1, marginRight: 22},
  cellHalo: {
    position: 'absolute',
    top: -12,
    left: -12,
    right: 10,
    bottom: -12,
    borderRadius: 26,
  },
  heroFrame: {
    height: 210,
    borderRadius: 20,
    borderWidth: 2,
    overflow: 'hidden',
    backgroundColor: C.card,
  },
  pressable: {flex: 1},
  heroGlyph: {
    position: 'absolute',
    top: 14,
    right: 18,
    fontSize: 64,
    fontWeight: '800',
    color: 'rgba(255,255,255,0.14)',
    includeFontPadding: false,
  },
  heroBottom: {position: 'absolute', left: 18, right: 18, bottom: 14},
  tag: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(0,112,209,0.9)',
    borderRadius: 6,
    paddingHorizontal: 8,
    paddingVertical: 3,
    marginBottom: 8,
  },
  tagText: {color: '#fff', fontSize: 10, fontWeight: '800', letterSpacing: 1.8},
  heroTitle: {color: '#fff', fontSize: 20, fontWeight: '800'},
  heroSub: {color: 'rgba(224,227,238,0.8)', fontSize: 12.5, marginTop: 3},
});
