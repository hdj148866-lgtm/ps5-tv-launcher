import React from 'react';
import Svg, {Circle, G, Line, Path, Polygon, Rect} from 'react-native-svg';

/**
 * Minimal hand-rolled SVG icon set (24x24 viewBox).
 * Using raw SVG primitives avoids the native font-linking overhead of
 * react-native-vector-icons — everything here is zero-config.
 */

function Wrap({size, children}) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      {children}
    </Svg>
  );
}

export function WifiIcon({size = 22, color = '#a0a5b5'}) {
  return (
    <Wrap size={size}>
      <Path d="M4.6 10.2a11 11 0 0 1 14.8 0" stroke={color} strokeWidth={2} strokeLinecap="round" />
      <Path d="M7.6 13.4a7 7 0 0 1 8.8 0" stroke={color} strokeWidth={2} strokeLinecap="round" />
      <Path d="M10.4 16.5a3.2 3.2 0 0 1 3.2 0" stroke={color} strokeWidth={2} strokeLinecap="round" />
      <Circle cx={12} cy={19.2} r={1.5} fill={color} />
    </Wrap>
  );
}

export function GearIcon({size = 24, color = '#a0a5b5'}) {
  return (
    <Wrap size={size}>
      {/* dashed heavy ring + hub reads as a cog at TV distance */}
      <Circle cx={12} cy={12} r={7.1} stroke={color} strokeWidth={3.4} strokeDasharray="3.4 3.1" />
      <Circle cx={12} cy={12} r={3} stroke={color} strokeWidth={2} />
    </Wrap>
  );
}

export function BellIcon({size = 24, color = '#a0a5b5'}) {
  return (
    <Wrap size={size}>
      <Path
        d="M12 3.2c-2.9 0-4.9 2.1-4.9 5v3.6L5.4 15h13.2l-1.7-3.2V8.2c0-2.9-2-5-4.9-5Z"
        stroke={color}
        strokeWidth={1.9}
        strokeLinejoin="round"
      />
      <Path d="M10.2 17.8a1.9 1.9 0 0 0 3.6 0" stroke={color} strokeWidth={1.9} strokeLinecap="round" />
      <Circle cx={12} cy={2.6} r={1.1} fill={color} />
    </Wrap>
  );
}

export function SearchIcon({size = 22, color = '#a0a5b5', strokeWidth = 2}) {
  return (
    <Wrap size={size}>
      <Circle cx={10.5} cy={10.5} r={6} stroke={color} strokeWidth={strokeWidth} />
      <Line x1={15.3} y1={15.3} x2={20.4} y2={20.4} stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" />
    </Wrap>
  );
}

export function GamepadIcon({size = 22, color = '#ffffff'}) {
  return (
    <Wrap size={size}>
      <Rect x={3} y={7.5} width={18} height={9.4} rx={4.7} stroke={color} strokeWidth={1.9} />
      <Line x1={6.2} y1={12.2} x2={9.4} y2={12.2} stroke={color} strokeWidth={1.7} strokeLinecap="round" />
      <Line x1={7.8} y1={10.6} x2={7.8} y2={13.8} stroke={color} strokeWidth={1.7} strokeLinecap="round" />
      <Circle cx={15.6} cy={10.9} r={1.15} fill={color} />
      <Circle cx={17.6} cy={13.4} r={1.15} fill={color} />
    </Wrap>
  );
}

export function FilmIcon({size = 22, color = '#a0a5b5'}) {
  return (
    <Wrap size={size}>
      <Rect x={3.5} y={5} width={17} height={14} rx={2.4} stroke={color} strokeWidth={1.9} />
      <Line x1={8.2} y1={5} x2={8.2} y2={19} stroke={color} strokeWidth={1.5} />
      <Line x1={15.8} y1={5} x2={15.8} y2={19} stroke={color} strokeWidth={1.5} />
      <Line x1={3.5} y1={12} x2={20.5} y2={12} stroke={color} strokeWidth={1.5} />
    </Wrap>
  );
}

export function CompassIcon({size = 22, color = '#a0a5b5'}) {
  return (
    <Wrap size={size}>
      <Circle cx={12} cy={12} r={8.4} stroke={color} strokeWidth={1.9} />
      <Polygon points="15.6,8.4 13.6,13.6 8.4,15.6 10.4,10.4" fill={color} />
    </Wrap>
  );
}

export function PlayIcon({size = 22, color = '#ffffff'}) {
  return (
    <Wrap size={size}>
      <Path d="M9 6.6 18.6 12 9 17.4Z" fill={color} stroke={color} strokeWidth={1.4} strokeLinejoin="round" />
    </Wrap>
  );
}

export function InfoIcon({size = 22, color = '#a0a5b5'}) {
  return (
    <Wrap size={size}>
      <Circle cx={12} cy={12} r={8.4} stroke={color} strokeWidth={1.9} />
      <Line x1={12} y1={11} x2={12} y2={16.6} stroke={color} strokeWidth={2} strokeLinecap="round" />
      <Circle cx={12} cy={7.7} r={1.25} fill={color} />
    </Wrap>
  );
}

export function TrashIcon({size = 22, color = '#a0a5b5'}) {
  return (
    <Wrap size={size}>
      <Line x1={4.8} y1={7} x2={19.2} y2={7} stroke={color} strokeWidth={1.9} strokeLinecap="round" />
      <Path
        d="M9.3 7V5.4A1.4 1.4 0 0 1 10.7 4h2.6a1.4 1.4 0 0 1 1.4 1.4V7"
        stroke={color}
        strokeWidth={1.8}
        strokeLinecap="round"
      />
      <Path
        d="M6.6 7l0.8 12a1.9 1.9 0 0 0 1.9 1.8h5.4a1.9 1.9 0 0 0 1.9-1.8L17.4 7"
        stroke={color}
        strokeWidth={1.8}
        strokeLinejoin="round"
      />
      <Line x1={10.2} y1={10.6} x2={10.4} y2={17.2} stroke={color} strokeWidth={1.6} strokeLinecap="round" />
      <Line x1={13.8} y1={10.6} x2={13.6} y2={17.2} stroke={color} strokeWidth={1.6} strokeLinecap="round" />
    </Wrap>
  );
}

export function GridIcon({size = 22, color = '#a0a5b5'}) {
  return (
    <Wrap size={size}>
      <Rect x={4.4} y={4.4} width={6.6} height={6.6} rx={1.7} stroke={color} strokeWidth={1.8} />
      <Rect x={13} y={4.4} width={6.6} height={6.6} rx={1.7} stroke={color} strokeWidth={1.8} />
      <Rect x={4.4} y={13} width={6.6} height={6.6} rx={1.7} stroke={color} strokeWidth={1.8} />
      <Rect x={13} y={13} width={6.6} height={6.6} rx={1.7} stroke={color} strokeWidth={1.8} />
    </Wrap>
  );
}

export function UserIcon({size = 22, color = '#ffffff'}) {
  return (
    <Wrap size={size}>
      <Circle cx={12} cy={8.6} r={3.4} stroke={color} strokeWidth={1.9} />
      <Path d="M6 19.4a6.6 6.6 0 0 1 12 0" stroke={color} strokeWidth={1.9} strokeLinecap="round" />
    </Wrap>
  );
}

export function ChevronDownIcon({size = 16, color = '#a0a5b5'}) {
  return (
    <Wrap size={size}>
      <Path d="M6 9.4 12 15.4 18 9.4" stroke={color} strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round" />
    </Wrap>
  );
}

export function OptionsIcon({size = 16, color = '#a0a5b5'}) {
  return (
    <Wrap size={size}>
      <G fill={color}>
        <Circle cx={6} cy={12} r={1.7} />
        <Circle cx={12} cy={12} r={1.7} />
        <Circle cx={18} cy={12} r={1.7} />
      </G>
    </Wrap>
  );
}
