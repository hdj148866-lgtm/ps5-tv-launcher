import React, {useEffect, useState} from 'react';
import {Image, Pressable, StyleSheet, Text, View} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Animated, {
  interpolate,
  interpolateColor,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';
import {C, METRICS, SPRINGS} from '../theme';
import {artFor} from '../utils/art';

const SIZES = {
  normal: {w: METRICS.CARD_W, h: METRICS.CARD_H, r: METRICS.CARD_R, icon: 62, glyph: 26, label: 14, gap: METRICS.CARD_GAP},
  small: {w: 172, h: 100, r: 14, icon: 44, glyph: 19, label: 13, gap: 16},
};

/**
 * A single shelf tile.
 *
 * Focus animation runs 100% on the UI thread:
 *  - scale 0.94 -> 1.14 with a spring (slight overshoot = PS5 "pop"),
 *  - border color interpolates to glowing white,
 *  - an accent halo blooms behind the card,
 *  - title label slides up underneath.
 * `zIndex` bumps the focused card over its neighbors while it scales.
 */
const AppCard = React.memo(
  React.forwardRef(function AppCard(
    {app, index, size = 'normal', onFocus, onPress, hasTVPreferredFocus, focusable = true},
    ref,
  ) {
    const S = SIZES[size] || SIZES.normal;
    const [focused, setFocused] = useState(false);
    const f = useSharedValue(0);

    useEffect(() => {
      f.value = withSpring(focused ? 1 : 0, SPRINGS.focus);
    }, [focused, f]);

    const cardStyle = useAnimatedStyle(() => ({
      transform: [
        {scale: interpolate(f.value, [0, 1], [0.94, 1.14])},
        {translateY: interpolate(f.value, [0, 1], [0, -3])},
      ],
      borderColor: interpolateColor(
        f.value,
        [0, 1],
        ['rgba(255,255,255,0)', 'rgba(255,255,255,0.92)'],
      ),
      opacity: interpolate(f.value, [0, 1], [0.72, 1]),
      zIndex: f.value > 0.4 ? 30 : 1,
    }));

    const haloStyle = useAnimatedStyle(() => ({
      opacity: interpolate(f.value, [0, 1], [0, 0.85]),
      transform: [{scale: interpolate(f.value, [0, 1], [0.9, 1.04])}],
    }));

    const labelStyle = useAnimatedStyle(() => ({
      opacity: interpolate(f.value, [0, 1], [0.15, 1]),
      transform: [{translateY: interpolate(f.value, [0, 1], [6, 0])}],
    }));

    const art = artFor(app);

    return (
      <View style={{width: S.w, marginRight: S.gap}}>
        <Animated.View
          style={[
            styles.halo,
            {
              borderRadius: S.r + 10,
              top: -10,
              left: -10,
              right: S.gap - 10,
              height: S.h + 20,
            },
            haloStyle,
          ]}>
          <LinearGradient
            colors={[art.accentSoft, art.accentSoft, 'rgba(0,112,209,0)']}
            locations={[0, 0.5, 1]}
            start={{x: 0.5, y: 0}}
            end={{x: 0.5, y: 1}}
            style={[StyleSheet.absoluteFill, {borderRadius: S.r + 10, opacity: 0.85}]}
          />
        </Animated.View>

        <Animated.View
          style={[
            styles.cardFrame,
            {width: S.w, height: S.h, borderRadius: S.r},
            cardStyle,
          ]}>
          <Pressable
            ref={ref}
            focusable={focusable}
            hasTVPreferredFocus={hasTVPreferredFocus}
            accessibilityLabel={`Open ${app.label}`}
            onFocus={() => {
              setFocused(true);
              onFocus && onFocus(index);
            }}
            onBlur={() => setFocused(false)}
            onPress={() => onPress && onPress(app, index)}
            style={styles.pressable}>
            <LinearGradient
              colors={art.cardGrad}
              start={{x: 0, y: 0}}
              end={{x: 1, y: 1}}
              style={[StyleSheet.absoluteFill, {borderRadius: S.r}]}
            />
            <View style={styles.center}>
              {app.icon ? (
                <Image
                  source={{uri: `data:image/png;base64,${app.icon}`}}
                  style={{width: S.icon, height: S.icon, borderRadius: S.icon * 0.22}}
                  resizeMode="contain"
                />
              ) : (
                <View
                  style={[
                    styles.glyphTile,
                    {
                      width: S.icon,
                      height: S.icon,
                      borderRadius: S.icon * 0.24,
                    },
                  ]}>
                  <Text style={[styles.glyph, {fontSize: S.glyph}]}>{art.glyph}</Text>
                </View>
              )}
            </View>
            {/* bottom inner scrim for depth */}
            <LinearGradient
              colors={['rgba(10,12,16,0)', 'rgba(10,12,16,0.35)']}
              start={{x: 0.5, y: 0.4}}
              end={{x: 0.5, y: 1}}
              style={[StyleSheet.absoluteFill, {borderRadius: S.r}]}
            />
          </Pressable>
        </Animated.View>

        <Animated.Text
          numberOfLines={1}
          style={[styles.label, {fontSize: S.label, width: S.w}, labelStyle]}>
          {app.label}
        </Animated.Text>
      </View>
    );
  }),
);

export default AppCard;

const styles = StyleSheet.create({
  halo: {
    position: 'absolute',
  },
  cardFrame: {
    borderWidth: 2,
    overflow: 'hidden',
    backgroundColor: C.card,
  },
  pressable: {
    flex: 1,
  },
  center: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  glyphTile: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.16)',
  },
  glyph: {
    color: '#ffffff',
    fontWeight: '800',
    includeFontPadding: false,
  },
  label: {
    color: C.sub,
    fontWeight: '600',
    marginTop: 12,
    letterSpacing: 0.3,
  },
});
