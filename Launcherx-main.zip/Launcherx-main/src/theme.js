/**
 * PS5-inspired design tokens.
 * The whole UI is tuned against the Android TV baseline density
 * (~960 x 540 dp on a 1080p panel, 1920 x 1080 px).
 */

export const C = {
  bg: '#0a0c10',
  bgSoft: '#10141c',
  card: '#161c28',
  cardLight: '#1e2634',
  accent: '#0070d1',
  accentDeep: '#00439c',
  text: '#ffffff',
  sub: '#a0a5b5',
  faint: 'rgba(255,255,255,0.06)',
  stroke: 'rgba(255,255,255,0.10)',
  strokeStrong: 'rgba(255,255,255,0.22)',
  danger: '#ff5a5a',
  success: '#3ddc84',
};

/** Gradient stops for the vignette stacked on top of key-art. */
export const VIGNETTE = [
  'rgba(10,12,16,0.25)',
  'rgba(10,12,16,0.55)',
  'rgba(10,12,16,0.96)',
];
export const VIGNETTE_LOCATIONS = [0, 0.42, 1];

export const METRICS = {
  HEADER_H: 84,
  NAV_H: 56,
  TITLE_H: 132,

  CARD_W: 244,
  CARD_H: 138,
  CARD_GAP: 22,
  CARD_R: 18,

  TRAY_CARD_H: 96,
  TRAY_CARD_R: 16,
};

export const SPRINGS = {
  focus: {damping: 16, stiffness: 210, mass: 0.7},
  snap: {damping: 20, stiffness: 300, mass: 0.8},
  tray: {damping: 22, stiffness: 190, mass: 0.9},
};

export const DUR = {
  crossfade: 300,
  shelfShift: 260,
  kenburns: 15000,
};

export const FONT = {
  mono: 'monospace',
};
