import {NativeModules, ToastAndroid} from 'react-native';
import SAMPLE_APPS from './sampleApps';

/**
 * JS facade for the Kotlin `AppLauncher` module
 * (see android-template/.../launcher/AppLauncherModule.kt).
 *
 * Every call degrades gracefully:
 *  - bridge missing (dev emulator without the native code) -> demo data /
 *    toast, so the entire UI is still drivable over D-PAD;
 *  - individual native failure -> rejected promise caught and surfaced as a
 *    toast instead of a crash.
 *
 * Provided native API:
 *   getInstalledApps(): Promise<Array<{
 *     label: string, packageName: string, icon: string|null (base64 png),
 *     isGame: boolean, isTV: boolean, category: string }>>>
 *   launchApp(packageName: string): Promise<boolean>
 *   getAppDetails(packageName: string): Promise<{
 *     versionName: string, storageBytes: number,
 *     firstInstallTime: number, lastUpdateTime: number, isGame: boolean }>
 *   requestUninstall(packageName: string): Promise<boolean>
 *   openAppSettings(packageName: string): Promise<boolean>
 *   openSystemSettings(): Promise<boolean>
 */

const N = NativeModules.AppLauncher;
const detailsCache = new Map();

function toast(msg) {
  try {
    ToastAndroid.show(msg, ToastAndroid.SHORT);
  } catch (e) {
    // no-op on non-Android
  }
}

async function getInstalledApps() {
  if (N && N.getInstalledApps) {
    try {
      const apps = await N.getInstalledApps();
      if (Array.isArray(apps) && apps.length) {
        return apps;
      }
    } catch (e) {
      // fall through to demo data
    }
  }
  toast('Native bridge not linked — demo catalog');
  return SAMPLE_APPS;
}

async function launchApp(packageName, label) {
  if (N && N.launchApp) {
    try {
      return await N.launchApp(packageName);
    } catch (e) {
      toast(`Unable to launch ${label || packageName}`);
      return false;
    }
  }
  toast(`(demo) Launch ${label || packageName}`);
  return true;
}

async function getAppDetails(app) {
  if (!app || !app.packageName) {
    return null;
  }
  const key = app.packageName;
  if (detailsCache.has(key)) {
    return detailsCache.get(key);
  }
  let details = null;
  if (N && N.getAppDetails) {
    try {
      details = await N.getAppDetails(key);
    } catch (e) {
      details = null;
    }
  }
  if (!details) {
    details = {
      versionName: '1.0.0',
      storageBytes: app.storageBytes != null ? app.storageBytes : 640 * 1024 * 1024,
      firstInstallTime: Date.now() - 30 * 86400000,
      lastUpdateTime: Date.now() - 3 * 86400000,
      isGame: !!app.isGame,
      demo: true,
    };
  }
  detailsCache.set(key, details);
  return details;
}

function clearDetailsCache(packageName) {
  if (packageName) {
    detailsCache.delete(packageName);
  }
}

async function requestUninstall(packageName, label) {
  if (N && N.requestUninstall) {
    try {
      return await N.requestUninstall(packageName);
    } catch (e) {
      toast(`Unable to uninstall ${label || packageName}`);
      return false;
    }
  }
  toast(`(demo) Uninstall ${label || packageName}`);
  return true;
}

async function openAppSettings(packageName) {
  if (N && N.openAppSettings) {
    try {
      return await N.openAppSettings(packageName);
    } catch (e) {
      return false;
    }
  }
  toast(`(demo) App settings: ${packageName}`);
  return true;
}

async function openSystemSettings() {
  if (N && N.openSystemSettings) {
    try {
      return await N.openSystemSettings();
    } catch (e) {
      return false;
    }
  }
  toast('(demo) System settings');
  return true;
}

const AppLauncherNative = {
  getInstalledApps,
  launchApp,
  getAppDetails,
  clearDetailsCache,
  requestUninstall,
  openAppSettings,
  openSystemSettings,
  isLinked: !!(N && N.getInstalledApps),
};

export default AppLauncherNative;
