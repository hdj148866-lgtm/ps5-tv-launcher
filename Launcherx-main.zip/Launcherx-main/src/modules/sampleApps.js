/**
 * Demo catalog used when the native bridge isn't linked yet
 * (e.g. running the JS on a stock emulator before the Kotlin module is in).
 * Icons are null -> the shelf renders generated monogram tiles.
 */
const GB = 1024 * 1024 * 1024;

export default [
  {label: 'YouTube', packageName: 'com.google.android.youtube.tv', icon: null, isGame: false, isTV: true, category: 'Video Players & Editors', storageBytes: 0.42 * GB},
  {label: 'Netflix', packageName: 'com.netflix.ninja', icon: null, isGame: false, isTV: true, category: 'Entertainment', storageBytes: 0.31 * GB},
  {label: 'Disney+', packageName: 'com.disney.disneyplus', icon: null, isGame: false, isTV: true, category: 'Entertainment', storageBytes: 0.28 * GB},
  {label: 'Prime Video', packageName: 'com.amazon.amazonvideo.livingroom', icon: null, isGame: false, isTV: true, category: 'Entertainment', storageBytes: 0.36 * GB},
  {label: 'Spotify', packageName: 'com.spotify.tv.android', icon: null, isGame: false, isTV: true, category: 'Music & Audio', storageBytes: 0.18 * GB},
  {label: 'Plex', packageName: 'com.plexapp.android', icon: null, isGame: false, isTV: true, category: 'Video Players & Editors', storageBytes: 0.52 * GB},
  {label: 'Twitch', packageName: 'tv.twitch.android.app', icon: null, isGame: false, isTV: true, category: 'Entertainment', storageBytes: 0.24 * GB},
  {label: 'Asphalt Legends', packageName: 'com.gameloft.android.ANMP.GloftA9HM', icon: null, isGame: true, isTV: true, category: 'Racing', storageBytes: 1.9 * GB},
  {label: 'Crossy Road', packageName: 'com.yodo1.crossyroad', icon: null, isGame: true, isTV: true, category: 'Arcade', storageBytes: 0.14 * GB},
  {label: 'Dead Cells', packageName: 'com.playdigious.deadcells.mobile', icon: null, isGame: true, isTV: true, category: 'Action', storageBytes: 0.86 * GB},
  {label: 'Beach Buggy Racing', packageName: 'com.vectorunit.purple.googleplay', icon: null, isGame: true, isTV: true, category: 'Racing', storageBytes: 0.09 * GB},
  {label: 'Minecraft', packageName: 'com.mojang.minecraftpe', icon: null, isGame: true, isTV: true, category: 'Sandbox', storageBytes: 0.74 * GB},
].map((a) => ({...a, storageBytes: Math.round(a.storageBytes), demo: true}));
