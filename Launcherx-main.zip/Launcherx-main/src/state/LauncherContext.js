import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useReducer,
  useRef,
} from 'react';
import {BackHandler, useTVEventHandler} from 'react-native';
import useSoundFX from '../hooks/useSoundFX';
import {focusNode} from '../utils/focus';

export const TABS = [
  {id: 'games', label: 'GAMES'},
  {id: 'media', label: 'MEDIA'},
  {id: 'explore', label: 'EXPLORE'},
  {id: 'search', label: 'SEARCH'},
];

/**
 * Focus "zones" the UI can be in. Zone transitions decide how global
 * D-PAD keys get rerouted by the central dispatcher below.
 *  boot -> shelf -> tray   (plus header/nav/explore/search)
 */
const initialState = {
  booted: false,
  apps: [],
  tab: 'games',
  zone: 'boot',
  focusedIndex: 0,
  // Focus memory, per shelf tab: leaving MEDIA on index 4 and coming back
  // lands you on index 4 again (PS5 behavior).
  lastIndex: {games: 0, media: 0},
  trayOpen: false,
  query: '',
};

function reducer(state, action) {
  switch (action.type) {
    case 'APPS_LOADED':
      return {
        ...state,
        apps: action.apps,
        booted: true,
        zone: 'shelf',
        focusedIndex: Math.min(state.lastIndex[state.tab] || 0, Math.max(action.apps.length - 1, 0)),
      };
    case 'SET_TAB': {
      const mem = state.lastIndex[action.id];
      return {
        ...state,
        tab: action.id,
        trayOpen: false,
        focusedIndex: mem == null ? 0 : mem,
      };
    }
    case 'FOCUS_APP': {
      const {index} = action;
      const next = {...state, focusedIndex: index, zone: action.zone || 'shelf'};
      if (state.tab === 'games' || state.tab === 'media') {
        next.lastIndex = {...state.lastIndex, [state.tab]: index};
      }
      return next;
    }
    case 'SET_ZONE':
      return state.zone === action.zone ? state : {...state, zone: action.zone};
    case 'OPEN_TRAY':
      return state.trayOpen ? state : {...state, trayOpen: true, zone: 'tray'};
    case 'CLOSE_TRAY':
      return state.trayOpen ? {...state, trayOpen: false} : state;
    case 'SET_QUERY':
      return {...state, query: action.query};
    default:
      return state;
  }
}

/** Filtered, visible list for the current tab. */
export function appsForTab(state) {
  const {apps, tab} = state;
  const games = apps.filter((a) => a.isGame);
  const media = apps.filter((a) => !a.isGame);
  switch (tab) {
    case 'games':
      // On a fresh emulator there may be no games — degrade to "all".
      return games.length >= 2 ? games : apps;
    case 'media':
      return media.length ? media : apps;
    default:
      return apps;
  }
}

/** The app currently being "staged" (drives background, title, tray). */
export function selectFocusedApp(state) {
  const list = appsForTab(state);
  const idx = Math.max(0, Math.min(state.focusedIndex, list.length - 1));
  return list[idx] || null;
}

const LauncherContext = createContext(null);

export function LauncherProvider({children}) {
  const [state, dispatch] = useReducer(reducer, initialState);
  const stateRef = useRef(state);
  stateRef.current = state;

  const sfx = useSoundFX();
  const sfxRef = useRef(sfx);
  sfxRef.current = sfx;

  /** Imperative focus targets, registered by AppShelf / ContextTray. */
  const cardRefs = useRef(new Map()).current;
  const trayRefs = useRef(new Map()).current;

  /** Optional extra key listeners (panels can subscribe). */
  const keySubs = useRef(new Set());
  const subscribeKeys = useCallback((fn) => {
    keySubs.current.add(fn);
    return () => keySubs.current.delete(fn);
  }, []);

  const returnFocusToShelf = useCallback(() => {
    const s = stateRef.current;
    const ref = cardRefs.get(s.focusedIndex);
    if (ref) {
      focusNode(ref);
    }
  }, [cardRefs]);

  // ------------------------------------------------------------------
  // Central D-PAD dispatcher. ONE global hook -> deterministic routing.
  // eventType on Android TV: 'up'|'down'|'left'|'right'|'select'|'menu'|
  // 'playPause'|'rewind'|'fastForward'|'longSelect' ...
  // ------------------------------------------------------------------
  useTVEventHandler((evt) => {
    if (!evt) {
      return;
    }
    keySubs.current.forEach((fn) => {
      try {
        fn(evt);
      } catch (e) {
        // a panel must never break global navigation
      }
    });

    const s = stateRef.current;
    const t = evt.eventType;

    if (t === 'menu' || t === 'm') {
      if (s.trayOpen) {
        dispatch({type: 'CLOSE_TRAY'});
        sfxRef.current.close();
        returnFocusToShelf();
      } else if (s.zone === 'shelf') {
        dispatch({type: 'OPEN_TRAY'});
        sfxRef.current.open();
      }
      return;
    }

    if (s.trayOpen) {
      if (t === 'up') {
        dispatch({type: 'CLOSE_TRAY'});
        sfxRef.current.close();
        returnFocusToShelf();
      }
      return;
    }

    if (s.zone === 'shelf' && t === 'down') {
      // Nothing natively focusable below the shelf -> we route D-PAD DOWN
      // into the contextual tray instead (PS5 activity-cards behavior).
      dispatch({type: 'OPEN_TRAY'});
      sfxRef.current.open();
    }
  });

  // TV remote "BACK" closes the tray first, before leaving the app.
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      const s = stateRef.current;
      if (s.trayOpen) {
        dispatch({type: 'CLOSE_TRAY'});
        sfxRef.current.close();
        returnFocusToShelf();
        return true;
      }
      if (s.tab !== 'games') {
        dispatch({type: 'SET_TAB', id: 'games'});
        return true;
      }
      return false;
    });
    return () => sub.remove();
  }, [returnFocusToShelf]);

  const value = useMemo(
    () => ({state, dispatch, sfx, cardRefs, trayRefs, subscribeKeys}),
    [state, sfx, cardRefs, trayRefs, subscribeKeys],
  );

  return <LauncherContext.Provider value={value}>{children}</LauncherContext.Provider>;
}

export function useLauncher() {
  const ctx = useContext(LauncherContext);
  if (!ctx) {
    throw new Error('useLauncher must be used inside <LauncherProvider>');
  }
  return ctx;
}
