import {useMemo} from 'react';

/**
 * Ambient UI sound effects (PS5-style nav ticks / select whoosh).
 * react-native-sound maps Sound.MAIN_BUNDLE to res/raw on Android.
 * The whole module is wrapped so the launcher keeps working if the
 * native sound package isn't linked — audio is a garnish, never a blocker.
 */

let Sound = null;
try {
  // eslint-disable-next-line global-require
  Sound = require('react-native-sound').default;
  if (Sound && Sound.setCategory) {
    Sound.setCategory('Playback', false);
  }
} catch (e) {
  Sound = null;
}

const cache = new Map();

function ensure(name) {
  if (!Sound) {
    return null;
  }
  if (!cache.has(name)) {
    try {
      const s = new Sound(name, Sound.MAIN_BUNDLE, () => {});
      s.setNumberOfLoops(0);
      cache.set(name, s);
    } catch (e) {
      cache.set(name, null);
    }
  }
  return cache.get(name);
}

export function playFX(name, volume) {
  const s = ensure(name);
  if (!s) {
    return;
  }
  try {
    if (s.isPlaying && s.isPlaying()) {
      s.stop();
    }
    if (volume != null) {
      s.setVolume(volume);
    }
    s.setCurrentTime(0);
    s.play(() => {});
  } catch (e) {
    // audio must never throw into the focus pipeline
  }
}

export default function useSoundFX() {
  return useMemo(
    () => ({
      tick: () => playFX('nav_tick.wav', 0.35),
      select: () => playFX('select.wav', 0.6),
      open: () => playFX('tray.wav', 0.5),
      close: () => playFX('tray.wav', 0.28),
    }),
    [],
  );
}
