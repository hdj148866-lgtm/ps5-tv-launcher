import {useEffect} from 'react';
import AppLauncherNative from '../modules/AppLauncherNative';
import {useLauncher} from '../state/LauncherContext';

/** Loads the real installed app catalog once at boot (falls back to demo data). */
export default function useInstalledApps() {
  const {dispatch} = useLauncher();
  useEffect(() => {
    let alive = true;
    AppLauncherNative.getInstalledApps()
      .then((apps) => {
        if (!alive) {
          return;
        }
        const sorted = [...apps].sort((a, b) =>
          String(a.label).localeCompare(String(b.label)),
        );
        dispatch({type: 'APPS_LOADED', apps: sorted});
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, [dispatch]);
}
