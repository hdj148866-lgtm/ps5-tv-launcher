import {useEffect, useRef, useState} from 'react';
import {Easing, runOnJS, useSharedValue, withTiming} from 'react-native-reanimated';

/**
 * Double-buffer cross-fade, driven entirely on the UI thread.
 *
 * Every time `key` changes:
 *   - the outgoing value is parked into `prev` (rendered at full opacity),
 *   - the incoming value becomes `cur` and fades 0 -> 1 on top of it,
 *   - when the timing completes, `prev` is dropped from the tree (runOnJS).
 *
 * Two absolutely-positioned layers -> classic, allocation-free cross-fade.
 *
 * @param value  current payload to display
 * @param key    identity used to detect a change (e.g. packageName)
 * @param duration fade length in ms
 */
export default function useCrossFade(value, key, duration = 300) {
  const [cur, setCur] = useState(value);
  const [prev, setPrev] = useState(null);
  const curRef = useRef(value);
  const keyRef = useRef(key);
  const t = useSharedValue(1);

  useEffect(() => {
    if (key === keyRef.current) {
      return;
    }
    const outgoing = curRef.current;
    keyRef.current = key;
    curRef.current = value;
    setPrev(outgoing);
    setCur(value);
    t.value = 0;
    t.value = withTiming(
      1,
      {duration, easing: Easing.out(Easing.quad)},
      (finished) => {
        'worklet';
        if (finished) {
          runOnJS(setPrev)(null);
        }
      },
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, duration]);

  return {cur, prev, t};
}
