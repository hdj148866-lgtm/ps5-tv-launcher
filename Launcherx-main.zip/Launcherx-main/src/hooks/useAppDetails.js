import {useEffect, useState} from 'react';
import AppLauncherNative from '../modules/AppLauncherNative';

/**
 * Lazily pulls (and caches natively-bridge side) extended package metadata:
 * version, install footprint, last update. Debounced so scrubbing across the
 * shelf doesn't spam the bridge — it only resolves once focus settles.
 */
export default function useAppDetails(app, delay = 220) {
  const [details, setDetails] = useState(null);
  const pkg = app && app.packageName;

  useEffect(() => {
    let alive = true;
    setDetails(null);
    if (!pkg) {
      return undefined;
    }
    const id = setTimeout(() => {
      AppLauncherNative.getAppDetails(app).then((res) => {
        if (alive) {
          setDetails(res);
        }
      });
    }, delay);
    return () => {
      alive = false;
      clearTimeout(id);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pkg, delay]);

  return details;
}
