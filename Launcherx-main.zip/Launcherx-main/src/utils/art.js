/**
 * Deterministic "key-art" generator.
 * Real key-art per installed app doesn't exist on Android, so we derive a
 * branded, per-package gradient pair + monogram glyph from a stable hash of
 * the package name. Same app -> same art, forever.
 */

export function hashStr(s) {
  let h = 0;
  for (let i = 0; i < s.length; i++) {
    h = (Math.imul(h, 31) + s.charCodeAt(i)) | 0;
  }
  return Math.abs(h);
}

function hslToHex(h, s, l) {
  s /= 100;
  l /= 100;
  const c = (1 - Math.abs(2 * l - 1)) * s;
  const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
  const m = l - c / 2;
  let r = 0;
  let g = 0;
  let b = 0;
  if (h < 60) [r, g, b] = [c, x, 0];
  else if (h < 120) [r, g, b] = [x, c, 0];
  else if (h < 180) [r, g, b] = [0, c, x];
  else if (h < 240) [r, g, b] = [0, x, c];
  else if (h < 300) [r, g, b] = [x, 0, c];
  else [r, g, b] = [c, 0, x];
  const to = (v) =>
    Math.round((v + m) * 255)
      .toString(16)
      .padStart(2, '0');
  return `#${to(r)}${to(g)}${to(b)}`;
}

export function hexToRgba(hex, alpha) {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgba(${r},${g},${b},${alpha})`;
}

function initials(label) {
  const clean = (label || 'A').trim();
  const words = clean.split(/\s+/);
  if (words.length >= 2) {
    return (words[0][0] + words[1][0]).toUpperCase();
  }
  return clean.slice(0, 2).toUpperCase();
}

const FALLBACK = {label: 'PS5', packageName: 'com.ps5.launcher'};

/**
 * @returns {{hue:number, grad:string[], cardGrad:string[], accent:string,
 *            accentSoft:string, glyph:string}}
 */
export function artFor(app) {
  const src = app && app.packageName ? app : FALLBACK;
  const hash = hashStr(src.packageName || src.label || 'app');
  const hue = hash % 360;
  const hi = hslToHex(hue, 58, 34);
  const deep = hslToHex((hue + 42) % 360, 64, 15);
  return {
    hue,
    // Full-screen stage gradient (kept deep/saturated so text stays legible).
    grad: [hslToHex(hue, 62, 24), deep],
    // Card face gradient.
    cardGrad: [hi, hslToHex((hue + 36) % 360, 58, 20)],
    accent: hi,
    accentSoft: hexToRgba(hi, 0.55),
    glyph: initials(src.label),
  };
}
