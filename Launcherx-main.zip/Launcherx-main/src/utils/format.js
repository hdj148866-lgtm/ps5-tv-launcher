const MONTHS = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
];

export function formatBytes(bytes) {
  if (bytes == null || bytes < 0) {
    return '—';
  }
  if (bytes >= 1 << 30) {
    return `${(bytes / (1 << 30)).toFixed(1)} GB`;
  }
  if (bytes >= 1 << 20) {
    return `${(bytes / (1 << 20)).toFixed(1)} MB`;
  }
  if (bytes >= 1 << 10) {
    return `${(bytes / (1 << 10)).toFixed(0)} KB`;
  }
  return `${bytes} B`;
}

/** @returns {{hhmm:string, mer:string}} e.g. {hhmm:'8:41', mer:'PM'} */
export function formatClock(d) {
  let h = d.getHours();
  const mer = h >= 12 ? 'PM' : 'AM';
  h = h % 12 || 12;
  return {hhmm: `${h}:${String(d.getMinutes()).padStart(2, '0')}`, mer};
}

export function formatDate(ms) {
  if (!ms) {
    return '—';
  }
  const d = new Date(Number(ms));
  return `${MONTHS[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}`;
}
