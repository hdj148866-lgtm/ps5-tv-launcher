import {findNodeHandle, UIManager} from 'react-native';

/**
 * Imperative TV focus helpers.
 * `UIManager.focus(tag)` is the same primitive React Native's TV layer uses
 * internally — it works on both the Paper and Fabric renderers for any view
 * marked `focusable`. Every call is wrapped so it can never crash a key path.
 */
export function focusNode(ref) {
  try {
    const node =
      typeof ref === 'number' ? ref : findNodeHandle(ref && ref.current ? ref.current : ref);
    if (!node) {
      return;
    }
    if (typeof UIManager.focus === 'function') {
      UIManager.focus(node);
    } else {
      UIManager.dispatchViewManagerCommand(node, 'focus', []);
    }
  } catch (e) {
    // intentionally ignored — focus requests are best-effort
  }
}

export function blurNode(ref) {
  try {
    const node =
      typeof ref === 'number' ? ref : findNodeHandle(ref && ref.current ? ref.current : ref);
    if (!node) {
      return;
    }
    if (typeof UIManager.blur === 'function') {
      UIManager.blur(node);
    } else {
      UIManager.dispatchViewManagerCommand(node, 'blur', []);
    }
  } catch (e) {
    // intentionally ignored
  }
}
