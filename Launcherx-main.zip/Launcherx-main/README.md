# 🎮 PS5-Style Android TV App Launcher (React Native / react-native-tvos)

A full, high-performance, D-Pad navigable home-launcher for Android TV that mirrors the
PlayStation 5 home menu: dynamic key-art stage, spring-animated app shelf,
contextual activity cards, ambient particles and UI sound effects — all animations
on the UI thread via Reanimated 3 worklets.

![stack](https://img.shields.io/badge/react--native--tvos-0.76-00439c) ![anim](https://img.shields.io/badge/reanimated-3.x-0070d1) ![sdk](https://img.shields.io/badge/android%20tv-28%2B-3ddc84)

---

## ✨ Feature map

| Layer | What it does |
|---|---|
| **Header** | Profile avatar with animated focus outline, pulsing notification dot, live clock (HH:MM AM/PM, tabular-nums), Wi-Fi glyph, focusable ⚙ that opens real Android TV Settings |
| **Nav belt** | `GAMES · MEDIA · EXPLORE · SEARCH` with a spring-driven shared-value underline; content switches **on focus** (no OK press) exactly like PS5 |
| **Background stage** | Per-app deterministic gradient "key-art" + monogram watermark, double-buffered 300 ms cross-fade, 15 s Ken-Burns drift, PS5 vignette |
| **App shelf** | Horizontal tiles: focus spring `0.94 → 1.14`, glowing white border, accent halo, slide-up label, auto-centering scroll, z-stack bump |
| **Contextual tray** | `DPAD_DOWN` from a tile lifts/dims the shelf and slides in staggered cards: **Play/Resume · Details (real storage + version) · App Settings · Uninstall** — with focus memory back to the exact tile |
| **Explore / Search** | Featured hero cards panel and a live-filtered search with its own results shelf |
| **Ambient** | 14 desynced drifting particles + synthesized `nav_tick / select / tray` WAVs via react-native-sound |
| **Native bridge** | Kotlin module: enumerates installed TV+phone apps (base64 icons), launches via leanback intents, storage stats, uninstall, app/system settings |

---

## 🧠 Architecture

```
App.js
└─ LauncherProvider (src/state/LauncherContext.js)      ← ONE focus state machine
   │   useTVEventHandler  → central D-PAD dispatcher     ← menu / up / down routing
   │   BackHandler        → tray-first back behavior
   │   cardRefs/trayRefs  → imperative focus registry (UIManager.focus)
   │
   └─ Shell
      ├─ BackgroundStage    ← useCrossFade(art, packageName)  (UI-thread double buffer)
      ├─ Particles          ← withRepeat loops, zero JS-thread cost
      ├─ Header             ← useClock(), focusable avatar/⚙/🔔
      ├─ NavBelt            ← measured underline via onLayout + withSpring
      ├─ games/media:  AppTitleStage (cross-faded hero) + AppShelf
      │     └─ AppShelf: ScrollView + center-by-padding + TVFocusGuideView
      │         destinations (focus memory) + AppCard (memoized, worklet styles)
      ├─ explore: ExplorePanel        search: SearchPanel
      └─ ContextTray (absolute)     ← FadeInDown stagger, hasTVPreferredFocus
```

**Focus model (important design decisions)**

1. **Spatial focus where Android is good at it, explicit routing where it isn't.**
   Nav↔shelf and header↔nav moves are native (positions are unambiguous). The two
   genuinely ambiguous transitions — shelf *down into tray* and tray *up back to the
   exact tile* — are intercepted in the single dispatcher (`zone` state machine).
2. **Focus memory** is implemented three ways, belt-and-braces: `lastIndex` per tab
   in the reducer, `TVFocusGuideView destinations={lastFocusedCard}`, and
   `UIManager.focus(findNodeHandle(ref))` on tray close.
3. **`hasTVPreferredFocus`** is driven declaratively (`i === focusedIndex && !trayOpen && zone !== 'nav'`),
   so boot lands on tile #1 and tab switches restore the remembered tile.
4. Every animated value is a **shared value** (`scale/border/halo/label/underline/tray`)
   — focus changes produce **zero** JS-thread layout work.

---

## 🚀 Getting started

```bash
# 1. Bootstrap a React Native project named PS5Launcher (matches app.json)
npx @react-native-community/cli@latest init PS5Launcher --skip-install
cd PS5Launcher

# 2. Copy this repo's files over the scaffold
#    (package.json, babel.config.js, metro.config.js, index.js, App.js, src/, android-template/)

# 3. Merge the native template into android/
cp -r android-template/app/src/main/AndroidManifest.xml      android/app/src/main/
cp -r android-template/app/src/main/java/com/ps5launcher/*   android/app/src/main/java/com/ps5launcher/
cp -r android-template/app/src/main/res/*                    android/app/src/main/res/

# 4. Swap react-native for the TV fork (already done in this package.json)
#    "react-native": "npm:react-native-tvos@0.76.9-0"
yarn install

# 5. Run on a TV target (Android Studio ▸ Device Manager ▸ TV 1080p, API 28+)
npx react-native run-android
```

> **Hermes + Reanimated:** the babel plugin (`react-native-reanimated/plugin`) is already
> last in `babel.config.js` — required. If you upgrade to Reanimated 4.x, switch that to
> `react-native-worklets/plugin`.
>
> **Expo users:** use `@react-native-tvos/config-plugins` (`withTV` / `TV` plugin) instead
> of the manual `android/` merge; the JS source is identical.
>
> **Demo mode:** if the Kotlin module isn't linked yet, the app runs on a built-in
> 12-app demo catalog and shows toasts for launch/uninstall — great for UI iteration.

### D-PAD map

| Input | Action |
|---|---|
| ◀ ▶ | move across tiles / tabs |
| ▲ | tiles → nav belt → header |
| ▼ (on a tile) | open Quick-Actions tray |
| ▲ (in tray) / BACK | close tray, focus returns to the same tile |
| OK / ENTER | launch app / activate |
| MENU (☰) | toggle Quick-Actions tray |

---

## ⚡ Performance checklist (60 fps on Chromecast / Firestick 4K)

- All focus/scroll/underline animations: **Reanimated worklets**, no `Animated` JS driver.
- Shelf uses a plain `ScrollView`, not `FlatList` — view recycling a focused TV row is a
  known focus-loss foot-gun; launchers have < ~150 tiles so this is strictly faster/safer.
- `AppCard` is `React.memo`; only the two tiles that change focus re-render.
- Key-art is **generated gradients** — no image decode on focus change; base64 real icons
  are decoded once by the OS, cached by `<Image>`.
- Cross-fade keeps exactly **2 layers**; `runOnJS` drops the old layer on completion.
- Test with **release builds**: dev mode + remote debugging starves the UI thread on TVs.
- Sound assets are 44.1 kHz mono ≤ 16 KB, preloaded, volume-capped.

## 🔧 Notes & extension points

- **Real key art:** replace `src/utils/art.js` with your CDN fetch (e.g. IGDB/SteamGridDB)
  keyed by `packageName`; `useCrossFade` already handles the swap pipeline.
- **Storage bytes** use `StorageStatsManager` when the user grants *Usage Access*
  (Settings → Apps → Special access); otherwise falls back to APK size silently.
- **Emulator keys:** arrows = D-PAD, Enter = select, Esc = back, `F1`/Menu key = menu.
- Tuning knobs live in `src/theme.js` (spring configs, card metrics, palette).

## 📁 Repo layout

```
ps5-launcher/
├── App.js                              # entry scaffold & layer cake
├── index.js / app.json / babel / metro / package.json
├── src/
│   ├── theme.js                        # PS5 palette, metrics, spring presets
│   ├── state/LauncherContext.js        # reducer + central TV dispatcher
│   ├── hooks/  useClock useCrossFade useSoundFX useInstalledApps useAppDetails
│   ├── utils/  art.js (key-art gen) · focus.js (imperative focus) · format.js
│   ├── modules/ AppLauncherNative.js · sampleApps.js (demo catalog)
│   └── components/ Header · NavBelt · BackgroundStage · AppTitleStage
│                   AppShelf · AppCard · ContextTray · ExplorePanel
│                   SearchPanel · Particles · FocusGuide · icons
└── android-template/                   # merge into android/
    └── app/src/main/
        ├── AndroidManifest.xml         # leanback + HOME + <queries> visibility
        ├── java/com/ps5launcher/MainApplication.kt
        ├── java/com/ps5launcher/launcher/AppLauncher{Module,Package}.kt
        └── res/{raw/*.wav, drawable-xhdpi/banner.png}
```
