import React from 'react';
import {StatusBar, StyleSheet, View} from 'react-native';
import Animated, {FadeIn} from 'react-native-reanimated';
import {C} from './src/theme';
import {LauncherProvider, useLauncher} from './src/state/LauncherContext';
import useInstalledApps from './src/hooks/useInstalledApps';
import BackgroundStage from './src/components/BackgroundStage';
import Particles from './src/components/Particles';
import Header from './src/components/Header';
import NavBelt from './src/components/NavBelt';
import AppTitleStage from './src/components/AppTitleStage';
import AppShelf from './src/components/AppShelf';
import ContextTray from './src/components/ContextTray';
import ExplorePanel from './src/components/ExplorePanel';
import SearchPanel from './src/components/SearchPanel';

/**
 * Layer cake (bottom -> top):
 *   BackgroundStage  (dynamic key-art + vignette, cross-fades)
 *   Particles        (ambient drifting motes)
 *   UI               (Header / NavBelt / Title / Shelf / panels)
 *   ContextTray      (absolute, slides over the shelf when open)
 */
function Shell() {
  const {state} = useLauncher();
  useInstalledApps();

  const browsing = state.tab === 'games' || state.tab === 'media';

  return (
    <View style={styles.root}>
      <StatusBar backgroundColor={C.bg} barStyle="light-content" />
      <BackgroundStage />
      <Particles />
      <Animated.View entering={FadeIn.duration(650)} style={styles.ui}>
        <Header />
        <NavBelt />
        {browsing ? (
          <View style={styles.main}>
            <AppTitleStage />
            <AppShelf />
          </View>
        ) : state.tab === 'explore' ? (
          <ExplorePanel />
        ) : (
          <SearchPanel />
        )}
        <ContextTray />
      </Animated.View>
    </View>
  );
}

export default function App() {
  return (
    <LauncherProvider>
      <Shell />
    </LauncherProvider>
  );
}

const styles = StyleSheet.create({
  root: {flex: 1, backgroundColor: C.bg},
  ui: {flex: 1},
  main: {flex: 1},
});
